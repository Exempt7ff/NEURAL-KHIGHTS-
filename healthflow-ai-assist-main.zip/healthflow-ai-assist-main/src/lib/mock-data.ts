import { Department, Doctor } from "./types";

export const departments: Department[] = [
  { id: "cardio", name: "Cardiology", icon: "Heart", description: "Heart & cardiovascular system" },
  { id: "neuro", name: "Neurology", icon: "Brain", description: "Brain & nervous system" },
  { id: "ortho", name: "Orthopedics", icon: "Bone", description: "Bones, joints & muscles" },
  { id: "derma", name: "Dermatology", icon: "Scan", description: "Skin, hair & nails" },
  { id: "gastro", name: "Gastroenterology", icon: "Stethoscope", description: "Digestive system" },
  { id: "pulmo", name: "Pulmonology", icon: "Wind", description: "Lungs & respiratory" },
  { id: "ent", name: "ENT", icon: "Ear", description: "Ear, nose & throat" },
  { id: "general", name: "General Medicine", icon: "Activity", description: "General health checkup" },
];

export const doctors: Doctor[] = [
  { id: "d1", name: "Dr. Sarah Chen", department: "cardio", specialty: "Interventional Cardiology", avatar: "SC", available: true, avgConsultationTime: 20, currentQueueLength: 3, rating: 4.8 },
  { id: "d2", name: "Dr. James Wilson", department: "cardio", specialty: "Electrophysiology", avatar: "JW", available: true, avgConsultationTime: 25, currentQueueLength: 5, rating: 4.6 },
  { id: "d3", name: "Dr. Priya Patel", department: "neuro", specialty: "Neurophysiology", avatar: "PP", available: true, avgConsultationTime: 30, currentQueueLength: 2, rating: 4.9 },
  { id: "d4", name: "Dr. Michael Brooks", department: "ortho", specialty: "Sports Medicine", avatar: "MB", available: true, avgConsultationTime: 15, currentQueueLength: 4, rating: 4.7 },
  { id: "d5", name: "Dr. Aisha Rahman", department: "derma", specialty: "Clinical Dermatology", avatar: "AR", available: true, avgConsultationTime: 15, currentQueueLength: 1, rating: 4.9 },
  { id: "d6", name: "Dr. David Kim", department: "gastro", specialty: "Hepatology", avatar: "DK", available: true, avgConsultationTime: 20, currentQueueLength: 3, rating: 4.5 },
  { id: "d7", name: "Dr. Emily Nguyen", department: "pulmo", specialty: "Critical Care", avatar: "EN", available: true, avgConsultationTime: 25, currentQueueLength: 2, rating: 4.8 },
  { id: "d8", name: "Dr. Robert Taylor", department: "ent", specialty: "Otolaryngology", avatar: "RT", available: true, avgConsultationTime: 15, currentQueueLength: 6, rating: 4.4 },
  { id: "d9", name: "Dr. Lisa Anderson", department: "general", specialty: "Internal Medicine", avatar: "LA", available: true, avgConsultationTime: 15, currentQueueLength: 7, rating: 4.6 },
];

export function triageSymptoms(symptoms: string) {
  const lower = symptoms.toLowerCase();
  
  const rules: { keywords: string[]; department: string; conditions: string[]; severity: "normal" | "urgent" | "critical" }[] = [
    { keywords: ["chest pain", "heart", "palpitation", "cardiac arrest", "heart attack"], department: "cardio", conditions: ["Possible cardiac event", "Angina", "Arrhythmia"], severity: "critical" },
    { keywords: ["headache", "migraine", "dizzy", "seizure", "numbness", "paralysis", "stroke"], department: "neuro", conditions: ["Migraine", "Tension headache", "Possible neurological event"], severity: "urgent" },
    { keywords: ["fracture", "bone", "joint pain", "sprain", "back pain", "knee"], department: "ortho", conditions: ["Musculoskeletal injury", "Joint inflammation", "Possible fracture"], severity: "normal" },
    { keywords: ["rash", "skin", "acne", "eczema", "itching", "allergy"], department: "derma", conditions: ["Dermatitis", "Allergic reaction", "Skin infection"], severity: "normal" },
    { keywords: ["stomach", "nausea", "vomit", "diarrhea", "abdomen", "digestive"], department: "gastro", conditions: ["Gastritis", "Food poisoning", "Digestive disorder"], severity: "normal" },
    { keywords: ["cough", "breathing", "asthma", "shortness of breath", "wheeze", "lung"], department: "pulmo", conditions: ["Respiratory infection", "Asthma exacerbation", "Bronchitis"], severity: "urgent" },
    { keywords: ["ear", "throat", "nose", "sinus", "hearing", "tonsil"], department: "ent", conditions: ["Sinusitis", "Tonsillitis", "Ear infection"], severity: "normal" },
    { keywords: ["fever", "cold", "flu", "fatigue", "weakness", "body ache"], department: "general", conditions: ["Viral infection", "Common cold", "General malaise"], severity: "normal" },
  ];

  // Check for critical keywords that override
  const criticalKeywords = ["chest pain", "heart attack", "cardiac arrest", "stroke", "paralysis", "unconscious", "severe bleeding", "cannot breathe"];
  const isCritical = criticalKeywords.some(k => lower.includes(k));
  
  const urgentKeywords = ["high fever", "severe pain", "difficulty breathing", "blood", "seizure", "head injury"];
  const isUrgent = urgentKeywords.some(k => lower.includes(k));

  let match = rules.find(r => r.keywords.some(k => lower.includes(k)));
  if (!match) {
    match = rules[rules.length - 1]; // default to general
  }

  let severity = match.severity;
  if (isCritical) severity = "critical";
  else if (isUrgent) severity = "urgent";

  return {
    severity,
    probableConditions: match.conditions,
    recommendedDepartment: match.department,
    confidence: isCritical || match.keywords.some(k => lower.includes(k)) ? 0.87 : 0.65,
    requiresImmediate: severity === "critical",
    insights: severity === "critical"
      ? "⚠️ Critical symptoms detected. Immediate medical attention is recommended. Priority booking enabled."
      : severity === "urgent"
        ? "Symptoms indicate urgency. Recommending priority consultation."
        : "Symptoms appear manageable. Standard consultation recommended.",
  };
}

export function recommendDoctor(departmentId: string): Doctor {
  const deptDoctors = doctors.filter(d => d.department === departmentId && d.available);
  // Weighted scoring: lower queue + higher rating = better
  deptDoctors.sort((a, b) => {
    const scoreA = a.currentQueueLength * a.avgConsultationTime - a.rating * 10;
    const scoreB = b.currentQueueLength * b.avgConsultationTime - b.rating * 10;
    return scoreA - scoreB;
  });
  return deptDoctors[0] || doctors[0];
}

let tokenCounter = 100;
export function generateTokenNumber(): string {
  tokenCounter++;
  return `HQ-${tokenCounter}`;
}
