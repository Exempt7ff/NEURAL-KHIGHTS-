export type Severity = "normal" | "urgent" | "critical";

export interface Department {
  id: string;
  name: string;
  icon: string;
  description: string;
}

export interface Doctor {
  id: string;
  name: string;
  department: string;
  specialty: string;
  avatar: string;
  available: boolean;
  avgConsultationTime: number; // minutes
  currentQueueLength: number;
  rating: number;
}

export interface TriageResult {
  severity: Severity;
  probableConditions: string[];
  recommendedDepartment: string;
  confidence: number;
  requiresImmediate: boolean;
  insights: string;
}

export interface QueueToken {
  id: string;
  tokenNumber: string;
  patientName: string;
  symptoms: string;
  severity: Severity;
  department: string;
  doctor: Doctor;
  position: number;
  estimatedWaitMinutes: number;
  status: "waiting" | "in-progress" | "completed" | "cancelled";
  bookedAt: Date;
  triageResult: TriageResult;
}
