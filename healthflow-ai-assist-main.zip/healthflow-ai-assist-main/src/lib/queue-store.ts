import { QueueToken, Severity } from "./types";

// Simple in-memory store for the MVP
let queue: QueueToken[] = [];
let listeners: (() => void)[] = [];

export function subscribe(listener: () => void) {
  listeners.push(listener);
  return () => { listeners = listeners.filter(l => l !== listener); };
}

function notify() {
  listeners.forEach(l => l());
}

export function addToQueue(token: QueueToken) {
  // Priority insertion: critical goes to front, urgent after critical
  if (token.severity === "critical") {
    const firstNonCritical = queue.findIndex(t => t.severity !== "critical" && t.status === "waiting");
    if (firstNonCritical === -1) queue.push(token);
    else queue.splice(firstNonCritical, 0, token);
  } else if (token.severity === "urgent") {
    const firstNormal = queue.findIndex(t => t.severity === "normal" && t.status === "waiting");
    if (firstNormal === -1) queue.push(token);
    else queue.splice(firstNormal, 0, token);
  } else {
    queue.push(token);
  }
  recalculatePositions();
  notify();
}

export function getQueue(): QueueToken[] {
  return [...queue];
}

export function getDoctorQueue(doctorId: string): QueueToken[] {
  return queue.filter(t => t.doctor.id === doctorId && t.status !== "completed" && t.status !== "cancelled");
}

export function getToken(tokenId: string): QueueToken | undefined {
  return queue.find(t => t.id === tokenId);
}

export function advanceQueue(doctorId: string) {
  const doctorTokens = queue.filter(t => t.doctor.id === doctorId);
  const inProgress = doctorTokens.find(t => t.status === "in-progress");
  if (inProgress) {
    inProgress.status = "completed";
  }
  const nextWaiting = doctorTokens.find(t => t.status === "waiting");
  if (nextWaiting) {
    nextWaiting.status = "in-progress";
  }
  recalculatePositions();
  notify();
}

export function updateTokenStatus(tokenId: string, status: QueueToken["status"]) {
  const token = queue.find(t => t.id === tokenId);
  if (token) {
    token.status = status;
    recalculatePositions();
    notify();
  }
}

function recalculatePositions() {
  const byDoctor = new Map<string, number>();
  queue.forEach(t => {
    if (t.status === "waiting") {
      const pos = (byDoctor.get(t.doctor.id) || 0) + 1;
      byDoctor.set(t.doctor.id, pos);
      t.position = pos;
      t.estimatedWaitMinutes = pos * t.doctor.avgConsultationTime;
    } else if (t.status === "in-progress") {
      t.position = 0;
      t.estimatedWaitMinutes = 0;
    }
  });
}
