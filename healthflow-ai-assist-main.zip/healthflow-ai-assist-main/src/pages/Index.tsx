import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { departments } from "@/lib/mock-data";
import {
  Heart, Brain, Bone, Scan, Stethoscope, Wind, Ear, Activity,
  ArrowRight, Sparkles, Shield, Clock, Users
} from "lucide-react";

const iconMap: Record<string, React.ReactNode> = {
  Heart: <Heart className="h-6 w-6" />,
  Brain: <Brain className="h-6 w-6" />,
  Bone: <Bone className="h-6 w-6" />,
  Scan: <Scan className="h-6 w-6" />,
  Stethoscope: <Stethoscope className="h-6 w-6" />,
  Wind: <Wind className="h-6 w-6" />,
  Ear: <Ear className="h-6 w-6" />,
  Activity: <Activity className="h-6 w-6" />,
};

const Index = () => {
  const [symptoms, setSymptoms] = useState("");
  const navigate = useNavigate();

  const handleSymptomSubmit = () => {
    if (symptoms.trim()) {
      navigate(`/triage?symptoms=${encodeURIComponent(symptoms.trim())}`);
    }
  };

  const handleDepartmentSelect = (deptId: string) => {
    navigate(`/doctors?department=${deptId}`);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl gradient-hero flex items-center justify-center">
              <Stethoscope className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">MediQueue</h1>
              <p className="text-xs text-muted-foreground">Smart Healthcare Assistant</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => navigate("/queue-status")}>
              Track Queue
            </Button>
            <Button variant="outline" size="sm" onClick={() => navigate("/doctor-dashboard")}>
              Doctor Login
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="py-16 lg:py-24">
        <div className="container mx-auto px-4 text-center max-w-3xl">
          <Badge className="mb-6 bg-primary/10 text-primary border-primary/20 px-4 py-1.5">
            <Sparkles className="h-3.5 w-3.5 mr-1.5" />
            AI-Powered Triage System
          </Badge>
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-4 leading-tight">
            Smarter Healthcare,
            <span className="block bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              Shorter Wait Times
            </span>
          </h2>
          <p className="text-lg text-muted-foreground mb-10 max-w-xl mx-auto">
            Describe your symptoms and let our AI recommend the right specialist, or select a department directly.
          </p>

          {/* Stats */}
          <div className="flex justify-center gap-8 mb-12">
            {[
              { icon: <Clock className="h-5 w-5" />, label: "Avg Wait", value: "12 min" },
              { icon: <Users className="h-5 w-5" />, label: "Patients Today", value: "284" },
              { icon: <Shield className="h-5 w-5" />, label: "AI Accuracy", value: "94%" },
            ].map(s => (
              <div key={s.label} className="text-center">
                <div className="flex items-center justify-center text-primary mb-1">{s.icon}</div>
                <div className="text-2xl font-bold text-foreground">{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Symptom Input */}
      <section className="pb-12">
        <div className="container mx-auto px-4 max-w-2xl">
          <Card className="p-6 shadow-lg border-primary/10">
            <h3 className="text-lg font-semibold text-foreground mb-1 flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              Describe Your Symptoms
            </h3>
            <p className="text-sm text-muted-foreground mb-4">
              Our AI will analyze your symptoms and recommend the best specialist
            </p>
            <Textarea
              placeholder="e.g., I've been experiencing chest pain and shortness of breath for the past 2 hours..."
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              className="min-h-[100px] mb-4 resize-none"
            />
            <Button
              variant="hero"
              size="lg"
              className="w-full"
              onClick={handleSymptomSubmit}
              disabled={!symptoms.trim()}
            >
              Analyze Symptoms
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </Card>
        </div>
      </section>

      {/* Department Selection */}
      <section className="pb-20">
        <div className="container mx-auto px-4 max-w-4xl">
          <h3 className="text-xl font-semibold text-foreground mb-2 text-center">Or Select a Department</h3>
          <p className="text-sm text-muted-foreground mb-8 text-center">Browse available departments and find the right specialist</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {departments.map((dept) => (
              <Card
                key={dept.id}
                className="p-5 cursor-pointer hover:shadow-md hover:border-primary/30 transition-all duration-200 group"
                onClick={() => handleDepartmentSelect(dept.id)}
              >
                <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary mb-3 group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                  {iconMap[dept.icon]}
                </div>
                <h4 className="font-medium text-foreground text-sm">{dept.name}</h4>
                <p className="text-xs text-muted-foreground mt-0.5">{dept.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;
