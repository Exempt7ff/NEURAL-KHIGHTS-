import { useState, useEffect, useSyncExternalStore } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { getQueue, getToken, subscribe } from "@/lib/queue-store";
import { QueueToken } from "@/lib/types";
import { ArrowLeft, Clock, Hash, Users, Search, RefreshCw } from "lucide-react";

const severityBadge = {
  normal: "bg-success/10 text-success border-success/20",
  urgent: "bg-warning/10 text-warning border-warning/20",
  critical: "bg-critical/10 text-critical border-critical/20 animate-pulse-soft",
};

const statusBadge = {
  waiting: "bg-muted text-muted-foreground",
  "in-progress": "bg-primary/10 text-primary",
  completed: "bg-success/10 text-success",
  cancelled: "bg-destructive/10 text-destructive",
};

const QueueStatusPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const tokenIdFromUrl = searchParams.get("token");
  const [searchToken, setSearchToken] = useState("");
  const [viewingToken, setViewingToken] = useState<QueueToken | null>(null);

  // Subscribe to queue updates
  const queue = useSyncExternalStore(subscribe, getQueue);

  useEffect(() => {
    if (tokenIdFromUrl) {
      const t = getToken(tokenIdFromUrl);
      if (t) setViewingToken(t);
    }
  }, [tokenIdFromUrl, queue]);

  const handleSearch = () => {
    const found = queue.find(t => t.tokenNumber.toLowerCase() === searchToken.toLowerCase() || t.id === searchToken);
    setViewingToken(found || null);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Home
          </Button>
          <h1 className="font-semibold text-foreground">Queue Status</h1>
          <div className="w-16" />
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Search */}
        {!tokenIdFromUrl && (
          <Card className="p-4 mb-8">
            <div className="flex gap-2">
              <Input
                placeholder="Enter token number (e.g., HQ-101)"
                value={searchToken}
                onChange={e => setSearchToken(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleSearch()}
              />
              <Button onClick={handleSearch}>
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </Card>
        )}

        {/* Token Details */}
        {viewingToken ? (
          <div className="animate-slide-up">
            <Card className="p-6 mb-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <p className="text-sm text-muted-foreground">Token Number</p>
                  <p className="text-3xl font-bold text-primary">{viewingToken.tokenNumber}</p>
                </div>
                <div className="flex flex-col gap-2 items-end">
                  <Badge className={severityBadge[viewingToken.severity]}>
                    {viewingToken.severity.toUpperCase()}
                  </Badge>
                  <Badge className={statusBadge[viewingToken.status]}>
                    {viewingToken.status === "in-progress" ? "🔵 In Progress" : viewingToken.status === "waiting" ? "⏳ Waiting" : viewingToken.status}
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-6 mb-6">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                    <Hash className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Position</p>
                    <p className="text-2xl font-bold text-foreground">
                      {viewingToken.status === "in-progress" ? "Now" : `#${viewingToken.position}`}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary">
                    <Clock className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Est. Wait</p>
                    <p className="text-2xl font-bold text-foreground">
                      {viewingToken.status === "in-progress" ? "Now" : `${viewingToken.estimatedWaitMinutes}m`}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Patient</span>
                  <span className="font-medium text-foreground">{viewingToken.patientName}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Doctor</span>
                  <span className="font-medium text-foreground">{viewingToken.doctor.name}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-border">
                  <span className="text-muted-foreground">Department</span>
                  <span className="font-medium text-foreground">{viewingToken.department}</span>
                </div>
                {viewingToken.symptoms && (
                  <div className="flex justify-between py-2">
                    <span className="text-muted-foreground">Symptoms</span>
                    <span className="font-medium text-foreground text-right max-w-[60%]">{viewingToken.symptoms}</span>
                  </div>
                )}
              </div>
            </Card>

            {/* Queue ahead */}
            {viewingToken.status === "waiting" && (
              <Card className="p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Users className="h-4 w-4 text-muted-foreground" />
                  <p className="text-sm font-medium text-foreground">
                    {viewingToken.position - 1} patient(s) ahead of you
                  </p>
                </div>
                <div className="flex gap-1">
                  {Array.from({ length: Math.min(viewingToken.position, 10) }).map((_, i) => (
                    <div
                      key={i}
                      className={`h-2 flex-1 rounded-full ${i === viewingToken.position - 1 ? "bg-primary" : "bg-muted-foreground/20"}`}
                    />
                  ))}
                </div>
              </Card>
            )}
          </div>
        ) : (
          <div className="text-center py-16">
            <div className="h-16 w-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
              <Search className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-1">Track Your Queue</h3>
            <p className="text-sm text-muted-foreground">Enter your token number above to see your live queue status</p>
          </div>
        )}

        {/* Live queue overview */}
        {queue.length > 0 && (
          <div className="mt-8">
            <h3 className="text-sm font-semibold text-foreground mb-3 flex items-center gap-2">
              <RefreshCw className="h-3.5 w-3.5 text-primary" />
              Live Queue ({queue.filter(t => t.status === "waiting" || t.status === "in-progress").length} active)
            </h3>
            <div className="space-y-2">
              {queue.filter(t => t.status !== "completed" && t.status !== "cancelled").slice(0, 8).map(t => (
                <div key={t.id} className="flex items-center justify-between p-3 bg-card rounded-lg border border-border text-sm">
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-primary">{t.tokenNumber}</span>
                    <span className="text-muted-foreground">{t.patientName}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={severityBadge[t.severity]} variant="outline">{t.severity}</Badge>
                    <Badge className={statusBadge[t.status]} variant="outline">{t.status}</Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default QueueStatusPage;
