import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { doctors, departments, generateTokenNumber } from "@/lib/mock-data";
import { addToQueue } from "@/lib/queue-store";
import { Severity, QueueToken } from "@/lib/types";
import { ArrowLeft, Clock, Star, Users, CheckCircle } from "lucide-react";

const DoctorsPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const departmentId = searchParams.get("department") || "general";
  const severity = (searchParams.get("severity") as Severity) || "normal";
  const symptoms = searchParams.get("symptoms") || "";
  const [patientName, setPatientName] = useState("");
  const [selectedDoctor, setSelectedDoctor] = useState<string | null>(null);
  const [booked, setBooked] = useState<QueueToken | null>(null);

  const dept = departments.find(d => d.id === departmentId);
  const deptDoctors = doctors.filter(d => d.department === departmentId && d.available);

  const handleBook = () => {
    if (!selectedDoctor || !patientName.trim()) return;
    const doctor = doctors.find(d => d.id === selectedDoctor)!;
    const token: QueueToken = {
      id: crypto.randomUUID(),
      tokenNumber: generateTokenNumber(),
      patientName: patientName.trim(),
      symptoms,
      severity,
      department: departmentId,
      doctor,
      position: doctor.currentQueueLength + 1,
      estimatedWaitMinutes: (doctor.currentQueueLength + 1) * doctor.avgConsultationTime,
      status: "waiting",
      bookedAt: new Date(),
      triageResult: {
        severity,
        probableConditions: [],
        recommendedDepartment: departmentId,
        confidence: 0.85,
        requiresImmediate: severity === "critical",
        insights: "",
      },
    };
    addToQueue(token);
    doctor.currentQueueLength++;
    setBooked(token);
  };

  if (booked) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="p-8 max-w-md w-full text-center animate-slide-up">
          <div className="h-16 w-16 rounded-full bg-success/10 flex items-center justify-center mx-auto mb-4">
            <CheckCircle className="h-8 w-8 text-success" />
          </div>
          <h2 className="text-2xl font-bold text-foreground mb-1">Booking Confirmed!</h2>
          <p className="text-muted-foreground text-sm mb-6">Your digital token has been generated</p>

          <div className="bg-muted rounded-xl p-6 mb-6">
            <p className="text-sm text-muted-foreground mb-1">Token Number</p>
            <p className="text-4xl font-bold text-primary">{booked.tokenNumber}</p>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm mb-6">
            <div className="text-left">
              <p className="text-muted-foreground">Doctor</p>
              <p className="font-medium text-foreground">{booked.doctor.name}</p>
            </div>
            <div className="text-left">
              <p className="text-muted-foreground">Department</p>
              <p className="font-medium text-foreground">{dept?.name}</p>
            </div>
            <div className="text-left">
              <p className="text-muted-foreground">Position in Queue</p>
              <p className="font-medium text-foreground">#{booked.position}</p>
            </div>
            <div className="text-left">
              <p className="text-muted-foreground">Est. Wait Time</p>
              <p className="font-medium text-foreground">{booked.estimatedWaitMinutes} min</p>
            </div>
          </div>

          {severity === "critical" && (
            <Badge className="bg-critical text-critical-foreground mb-4">🚨 Priority Queue - Critical</Badge>
          )}

          <div className="flex flex-col gap-2">
            <Button variant="hero" onClick={() => navigate(`/queue-status?token=${booked.id}`)}>
              Track Queue Status
            </Button>
            <Button variant="outline" onClick={() => navigate("/")}>
              Back to Home
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <Button variant="ghost" size="sm" onClick={() => navigate(-1)}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Back
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <h2 className="text-2xl font-bold text-foreground mb-1">{dept?.name}</h2>
        <p className="text-muted-foreground text-sm mb-6">Select a doctor to book your appointment</p>

        {severity === "critical" && (
          <div className="mb-6 p-3 rounded-lg gradient-critical text-primary-foreground text-sm">
            🚨 Priority booking enabled — you will be placed at the front of the queue
          </div>
        )}

        <div className="mb-6">
          <label className="text-sm font-medium text-foreground mb-2 block">Patient Name</label>
          <Input
            placeholder="Enter your full name"
            value={patientName}
            onChange={e => setPatientName(e.target.value)}
          />
        </div>

        <div className="space-y-3 mb-6">
          {deptDoctors.map(doc => (
            <Card
              key={doc.id}
              className={`p-4 cursor-pointer transition-all duration-200 ${selectedDoctor === doc.id ? "border-primary shadow-md ring-2 ring-primary/20" : "hover:border-primary/30"}`}
              onClick={() => setSelectedDoctor(doc.id)}
            >
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
                  {doc.avatar}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h4 className="font-semibold text-foreground">{doc.name}</h4>
                    {selectedDoctor === doc.id && <CheckCircle className="h-4 w-4 text-primary" />}
                  </div>
                  <p className="text-xs text-muted-foreground">{doc.specialty}</p>
                </div>
                <div className="flex gap-4 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Star className="h-3.5 w-3.5 text-warning" />
                    {doc.rating}
                  </div>
                  <div className="flex items-center gap-1">
                    <Users className="h-3.5 w-3.5" />
                    {doc.currentQueueLength} in queue
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="h-3.5 w-3.5" />
                    ~{doc.avgConsultationTime}m
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        <Button
          variant="hero"
          size="lg"
          className="w-full"
          disabled={!selectedDoctor || !patientName.trim()}
          onClick={handleBook}
        >
          {severity === "critical" ? "🚨 Priority Book Now" : "Book Appointment"}
        </Button>
      </div>
    </div>
  );
};

export default DoctorsPage;
