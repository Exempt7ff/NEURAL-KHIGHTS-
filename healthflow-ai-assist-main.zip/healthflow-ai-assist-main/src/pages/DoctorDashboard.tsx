import { useState, useSyncExternalStore } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { doctors } from "@/lib/mock-data";
import { getDoctorQueue, advanceQueue, subscribe, getQueue } from "@/lib/queue-store";
import { Doctor, QueueToken } from "@/lib/types";
import {
  ArrowLeft, ChevronRight, Clock, LogIn, Users,
  AlertTriangle, CheckCircle, Stethoscope, Calendar
} from "lucide-react";

const severityColor = {
  normal: "bg-success/10 text-success",
  urgent: "bg-warning/10 text-warning",
  critical: "bg-critical/10 text-critical animate-pulse-soft",
};

const DoctorDashboard = () => {
  const navigate = useNavigate();
  const [loggedIn, setLoggedIn] = useState(false);
  const [selectedDoctorId, setSelectedDoctorId] = useState("");
  const [pin, setPin] = useState("");

  // Subscribe to live queue updates
  const allQueue = useSyncExternalStore(subscribe, getQueue);

  const doctor = doctors.find(d => d.id === selectedDoctorId);
  const doctorQueue = doctor ? getDoctorQueue(doctor.id) : [];
  const currentPatient = doctorQueue.find(t => t.status === "in-progress");
  const waitingPatients = doctorQueue.filter(t => t.status === "waiting");

  const handleLogin = () => {
    if (selectedDoctorId && pin === "1234") {
      setLoggedIn(true);
    }
  };

  const handleNextPatient = () => {
    if (doctor) advanceQueue(doctor.id);
  };

  if (!loggedIn) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="p-8 max-w-md w-full animate-slide-up">
          <div className="text-center mb-6">
            <div className="h-14 w-14 rounded-xl gradient-hero flex items-center justify-center mx-auto mb-4">
              <Stethoscope className="h-7 w-7 text-primary-foreground" />
            </div>
            <h2 className="text-xl font-bold text-foreground">Doctor Dashboard</h2>
            <p className="text-sm text-muted-foreground">Login to manage your patient queue</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">Select Doctor</label>
              <select
                className="w-full h-10 px-3 rounded-md border border-input bg-background text-foreground text-sm"
                value={selectedDoctorId}
                onChange={e => setSelectedDoctorId(e.target.value)}
              >
                <option value="">Choose your profile...</option>
                {doctors.map(d => (
                  <option key={d.id} value={d.id}>{d.name} — {d.specialty}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground mb-1.5 block">PIN</label>
              <Input
                type="password"
                placeholder="Enter PIN (demo: 1234)"
                value={pin}
                onChange={e => setPin(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleLogin()}
              />
            </div>
            <Button variant="hero" className="w-full" onClick={handleLogin} disabled={!selectedDoctorId || !pin}>
              <LogIn className="h-4 w-4 mr-1" /> Login
            </Button>
          </div>

          <Button variant="ghost" size="sm" className="w-full mt-4" onClick={() => navigate("/")}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Back to Home
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">
              {doctor?.avatar}
            </div>
            <div>
              <h1 className="font-semibold text-foreground">{doctor?.name}</h1>
              <p className="text-xs text-muted-foreground">{doctor?.specialty}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="text-xs">
              <Calendar className="h-3 w-3 mr-1" />
              Available
            </Badge>
            <Button variant="ghost" size="sm" onClick={() => { setLoggedIn(false); setPin(""); }}>
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6 max-w-4xl">
        {/* Stats row */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card className="p-4 text-center">
            <p className="text-2xl font-bold text-primary">{waitingPatients.length}</p>
            <p className="text-xs text-muted-foreground">Waiting</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-2xl font-bold text-foreground">{currentPatient ? 1 : 0}</p>
            <p className="text-xs text-muted-foreground">In Progress</p>
          </Card>
          <Card className="p-4 text-center">
            <p className="text-2xl font-bold text-muted-foreground">
              {doctorQueue.filter(t => t.status === "completed").length}
            </p>
            <p className="text-xs text-muted-foreground">Completed</p>
          </Card>
        </div>

        {/* Current patient */}
        <div className="mb-6">
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">Current Patient</h3>
          {currentPatient ? (
            <Card className="p-5 border-primary/30 bg-primary/5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-full gradient-hero flex items-center justify-center text-primary-foreground font-bold">
                    {currentPatient.patientName.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-foreground">{currentPatient.patientName}</p>
                    <p className="text-sm text-muted-foreground">{currentPatient.tokenNumber}</p>
                    {currentPatient.symptoms && (
                      <p className="text-xs text-muted-foreground mt-1">Symptoms: {currentPatient.symptoms}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={severityColor[currentPatient.severity]}>{currentPatient.severity}</Badge>
                  <Button size="sm" variant="success" onClick={handleNextPatient}>
                    <CheckCircle className="h-4 w-4 mr-1" /> Complete
                  </Button>
                </div>
              </div>
            </Card>
          ) : (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground text-sm">No patient in progress</p>
              {waitingPatients.length > 0 && (
                <Button size="sm" variant="hero" className="mt-3" onClick={handleNextPatient}>
                  <ChevronRight className="h-4 w-4 mr-1" /> Call Next Patient
                </Button>
              )}
            </Card>
          )}
        </div>

        {/* Waiting Queue */}
        <div>
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-3">
            Waiting Queue ({waitingPatients.length})
          </h3>
          {waitingPatients.length === 0 ? (
            <Card className="p-8 text-center">
              <Users className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-muted-foreground text-sm">No patients waiting</p>
            </Card>
          ) : (
            <div className="space-y-2">
              {waitingPatients.map((token, idx) => (
                <Card key={token.id} className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="h-8 w-8 rounded-lg bg-muted flex items-center justify-center text-sm font-bold text-muted-foreground">
                        {idx + 1}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <p className="font-medium text-foreground text-sm">{token.patientName}</p>
                          <span className="text-xs font-mono text-primary">{token.tokenNumber}</span>
                        </div>
                        {token.symptoms && (
                          <p className="text-xs text-muted-foreground truncate max-w-xs">{token.symptoms}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={severityColor[token.severity]} variant="outline">
                        {token.severity === "critical" && <AlertTriangle className="h-3 w-3 mr-1" />}
                        {token.severity}
                      </Badge>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        ~{token.estimatedWaitMinutes}m
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Next patient button */}
        {waitingPatients.length > 0 && !currentPatient && (
          <div className="mt-6">
            <Button variant="hero" size="lg" className="w-full" onClick={handleNextPatient}>
              <ChevronRight className="h-5 w-5 mr-1" /> Call Next Patient
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default DoctorDashboard;
