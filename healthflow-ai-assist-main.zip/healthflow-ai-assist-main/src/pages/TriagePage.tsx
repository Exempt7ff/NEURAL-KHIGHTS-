import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { triageSymptoms, departments, recommendDoctor } from "@/lib/mock-data";
import { TriageResult } from "@/lib/types";
import { AlertTriangle, ArrowLeft, ArrowRight, CheckCircle, Info, ShieldAlert, Sparkles } from "lucide-react";

const severityConfig = {
  normal: { label: "Normal", className: "bg-success text-success-foreground", icon: <CheckCircle className="h-5 w-5" /> },
  urgent: { label: "Urgent", className: "bg-warning text-warning-foreground", icon: <AlertTriangle className="h-5 w-5" /> },
  critical: { label: "Critical", className: "bg-critical text-critical-foreground animate-pulse-soft", icon: <ShieldAlert className="h-5 w-5" /> },
};

const TriagePage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const symptoms = searchParams.get("symptoms") || "";
  const [result, setResult] = useState<TriageResult | null>(null);
  const [analyzing, setAnalyzing] = useState(true);

  useEffect(() => {
    if (!symptoms) { navigate("/"); return; }
    const timer = setTimeout(() => {
      setResult(triageSymptoms(symptoms));
      setAnalyzing(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, [symptoms, navigate]);

  if (analyzing) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center animate-slide-up">
          <div className="h-16 w-16 rounded-2xl gradient-hero flex items-center justify-center mx-auto mb-6">
            <Sparkles className="h-8 w-8 text-primary-foreground animate-pulse-soft" />
          </div>
          <h2 className="text-xl font-semibold text-foreground mb-2">Analyzing Symptoms</h2>
          <p className="text-muted-foreground text-sm">AI is processing your symptoms...</p>
          <div className="mt-6 flex justify-center gap-1">
            {[0, 1, 2].map(i => (
              <div key={i} className="h-2 w-2 rounded-full bg-primary animate-pulse-soft" style={{ animationDelay: `${i * 0.3}s` }} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (!result) return null;

  const sev = severityConfig[result.severity];
  const dept = departments.find(d => d.id === result.recommendedDepartment);

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <Button variant="ghost" size="sm" onClick={() => navigate("/")}>
            <ArrowLeft className="h-4 w-4 mr-1" /> Back
          </Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Critical Alert */}
        {result.severity === "critical" && (
          <div className="mb-6 p-4 rounded-xl gradient-critical text-primary-foreground animate-slide-up">
            <div className="flex items-center gap-3">
              <ShieldAlert className="h-6 w-6 flex-shrink-0" />
              <div>
                <p className="font-semibold">🚨 Immediate Medical Attention Required</p>
                <p className="text-sm opacity-90">Critical symptoms detected. Priority booking has been enabled.</p>
              </div>
            </div>
          </div>
        )}

        <Card className="p-6 mb-6 animate-slide-up">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-foreground">Triage Assessment</h2>
            <Badge className={sev.className}>
              {sev.icon}
              <span className="ml-1.5">{sev.label}</span>
            </Badge>
          </div>

          <div className="mb-4">
            <p className="text-sm text-muted-foreground mb-1">Your Symptoms</p>
            <p className="text-foreground bg-muted p-3 rounded-lg text-sm">{symptoms}</p>
          </div>

          <div className="mb-4">
            <p className="text-sm text-muted-foreground mb-2">Probable Conditions</p>
            <div className="flex flex-wrap gap-2">
              {result.probableConditions.map(c => (
                <Badge key={c} variant="secondary" className="text-xs">{c}</Badge>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/5 border border-primary/10">
            <Info className="h-4 w-4 text-primary flex-shrink-0" />
            <p className="text-sm text-foreground">{result.insights}</p>
          </div>

          <div className="mt-4 flex items-center justify-between text-sm">
            <span className="text-muted-foreground">AI Confidence</span>
            <div className="flex items-center gap-2">
              <div className="h-2 w-24 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-primary rounded-full" style={{ width: `${result.confidence * 100}%` }} />
              </div>
              <span className="font-medium text-foreground">{Math.round(result.confidence * 100)}%</span>
            </div>
          </div>
        </Card>

        <Card className="p-6 mb-6 animate-slide-up" style={{ animationDelay: "0.1s" }}>
          <h3 className="font-semibold text-foreground mb-2">Recommended Department</h3>
          <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
            <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold">
              {dept?.name.charAt(0)}
            </div>
            <div>
              <p className="font-medium text-foreground">{dept?.name}</p>
              <p className="text-xs text-muted-foreground">{dept?.description}</p>
            </div>
          </div>
        </Card>

        <Button
          variant={result.severity === "critical" ? "critical" : "hero"}
          size="lg"
          className="w-full"
          onClick={() => navigate(`/doctors?department=${result.recommendedDepartment}&severity=${result.severity}&symptoms=${encodeURIComponent(symptoms)}`)}
        >
          {result.severity === "critical" ? "🚨 Priority Book Now" : "View Available Doctors"}
          <ArrowRight className="h-4 w-4 ml-1" />
        </Button>
      </div>
    </div>
  );
};

export default TriagePage;
